// src/services/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getDatabase } from "firebase/database";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBELVhTt1VtjNCAwsQICyECq234feFqbjM",
  authDomain: "bodhai-a4022.firebaseapp.com",
  databaseURL: "https://bodhai-a4022-default-rtdb.firebaseio.com",
  projectId: "bodhai-a4022",
  storageBucket: "bodhai-a4022.firebasestorage.app",
  messagingSenderId: "158976010022",
  appId: "1:158976010022:web:3a206a27d4e43d1c3703e7",
  measurementId: "G-Y48PJGR2N5"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getDatabase(app);
export const firestore = getFirestore(app);
