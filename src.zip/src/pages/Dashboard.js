import React from "react";
import { auth } from "../services/firebase";
import TestMCQ from "../components/TestMCQ";
import TestCoding from "../components/TestCoding";
import AdminUpload from "../components/AdminUpload";
import ViewResults from "../components/ViewResults";
import "./Dashboard.css"; // Assuming you have some styles in this file
import InvitePage from "./InvitePage";

function Dashboard({ user }) {
  const [view, setView] = React.useState("home");

  const logout = () => {
    auth.signOut();
    localStorage.removeItem("user");
    window.location.reload();
  };

  return (
    <div className="dashboard-wrapper">
  <h2>👋 Welcome, {user.displayName || user.email}</h2>

  <div className="dashboard-buttons">
    <button onClick={() => setView("mcq")}>📝 Start MCQ Test</button>
    <button onClick={() => setView("coding")}>💻 Start Coding Test</button>
    <button onClick={() => setView("admin")}>⚙️ Admin Panel</button>
    <button onClick={() => setView("results")}>📊 View Results</button>
    
    <button onClick={() => window.open("invite")}>📩 Invite Friends</button>
    <button onClick={logout}>🚪 Logout</button>
  </div>

  <div className="dashboard-content">
    {view === "mcq" && <TestMCQ user={user} />}
    {view === "coding" && <TestCoding user={user} />}
    {view === "results" && <ViewResults user={user} />}
    {view === "invite" && < InvitePage />}
    
    {/* Admin Panel */}
    {view === "admin" && user.isAdmin && (
      <div className="admin-panel">
        <h3>Admin Panel</h3>
        <p>Upload new questions or manage existing ones.</p>
      </div>
    )}
    {view === "admin" && user.isAdmin && <AdminUpload user={user} />}
    {view === "admin" && !user.isAdmin && <p>You do not have admin access.</p>}
    
    {/* Show AdminUpload component only if user is admin */}
    {/* {view === "admin" && <AdminUpload  />} */}
    
    {view === "home" && <p>Select an option above to get started.</p>}
  </div>
</div>


  );
}

export default Dashboard;
